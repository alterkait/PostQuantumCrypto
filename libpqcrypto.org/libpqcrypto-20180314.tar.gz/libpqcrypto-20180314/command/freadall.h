#ifndef freadall_h
#define freadall_h

#include <stdio.h>

extern unsigned char *freadall(unsigned long long *,unsigned long long,unsigned long long,FILE *);

#endif
