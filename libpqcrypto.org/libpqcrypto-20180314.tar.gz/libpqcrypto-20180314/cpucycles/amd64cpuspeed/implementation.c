#include "cpucycles.h"
const char cpucycles_implementation[] = "amd64cpuspeed";
