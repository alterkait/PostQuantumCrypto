#include "cpucycles.h"
const char cpucycles_implementation[] = "dev4ns";
