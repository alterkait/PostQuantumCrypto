#include "cpucycles.h"
const char cpucycles_implementation[] = "ia64cpuinfo";
