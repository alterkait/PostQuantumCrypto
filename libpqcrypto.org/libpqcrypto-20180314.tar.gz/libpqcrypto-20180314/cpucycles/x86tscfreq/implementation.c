#include "cpucycles.h"
const char cpucycles_implementation[] = "x86tscfreq";
