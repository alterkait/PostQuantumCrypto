#include <stddef.h>
#include <openssl/opensslv.h>
#include "crypto_hash.h"
const char crypto_hash_version[] = OPENSSL_VERSION_TEXT;
