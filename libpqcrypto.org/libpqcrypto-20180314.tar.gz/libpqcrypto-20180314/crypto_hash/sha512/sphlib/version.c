#include "crypto_hash.h"

const char crypto_hash_version[] = "SPHLIB 3.0";
