#ifndef KECCAK_F_H
#define KECCAK_F_H
uint64_t **keccak_f(uint64_t **);
#endif
