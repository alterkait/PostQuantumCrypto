/*
  This file is for the Berlekamp-Massey algorithm
*/

#ifndef BM_H
#define BM_H

void bm(gf *, gf *);

#endif

