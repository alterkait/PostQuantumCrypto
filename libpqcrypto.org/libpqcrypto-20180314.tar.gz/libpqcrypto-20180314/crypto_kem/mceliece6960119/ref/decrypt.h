/*
  This file is for Nieddereiter decryption
*/

#ifndef DECRYPT_H
#define DECRYPT_H

int decrypt(unsigned char *, const unsigned char *, const unsigned char *);

#endif

