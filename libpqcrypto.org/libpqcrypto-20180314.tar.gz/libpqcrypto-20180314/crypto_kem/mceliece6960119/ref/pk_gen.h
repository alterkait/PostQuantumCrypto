/*
  This file is for public-key generation
*/

#ifndef PK_GEN_H
#define PK_GEN_H

#include "gf.h"

int pk_gen(unsigned char *, unsigned char *);

#endif

