#ifndef BENES_H
#define BENES_H

#include "vec128.h"

void benes(vec128 *, const unsigned char *, int);

#endif

