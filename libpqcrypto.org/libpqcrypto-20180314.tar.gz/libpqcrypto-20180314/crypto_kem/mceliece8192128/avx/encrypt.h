#ifndef ENCRYPT_H
#define ENCRYPT_H

void encrypt(unsigned char *, const unsigned char *, unsigned char *);

#endif

