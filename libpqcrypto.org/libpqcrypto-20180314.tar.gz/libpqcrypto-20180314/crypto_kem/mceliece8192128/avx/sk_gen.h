#ifndef SK_GEN_H
#define SK_GEN_H

void sk_gen(unsigned char *);

#endif

