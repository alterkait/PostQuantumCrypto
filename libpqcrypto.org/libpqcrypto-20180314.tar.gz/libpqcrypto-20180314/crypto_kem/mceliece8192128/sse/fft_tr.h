#ifndef FFT_TR_H
#define FFT_TR_H

#include "params.h"
#include "vec128.h"

void fft_tr(vec128 [][GFBITS], vec128 [][ GFBITS ]);

#endif

