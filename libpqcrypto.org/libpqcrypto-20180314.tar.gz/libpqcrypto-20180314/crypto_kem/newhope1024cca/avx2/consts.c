#include <stdint.h>
#include "params.h"

const double q_vector[4] = {NEWHOPE_Q, NEWHOPE_Q, NEWHOPE_Q, NEWHOPE_Q};


const double qinv_vector[4] = {.00008137358613394092,.00008137358613394092,.00008137358613394092,.00008137358613394092};
const double neg2[4] = {1.,-1.,1.,-1.};
const double neg4[4] = {1.,1.,-1.,-1.};

