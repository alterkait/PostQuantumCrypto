#ifndef hide_h
#define hide_h

#include "crypto_int32.h"

extern void hide(unsigned char *,unsigned char *,const unsigned char *,const unsigned char *);

#endif
