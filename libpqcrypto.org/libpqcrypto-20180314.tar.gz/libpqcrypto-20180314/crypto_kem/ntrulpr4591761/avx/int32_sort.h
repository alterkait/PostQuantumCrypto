#ifndef int32_sort_h
#define int32_sort_h

#include "crypto_int32.h"

extern void int32_sort(crypto_int32 *,int);

#endif
